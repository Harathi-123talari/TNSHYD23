package com.sriindu.runningthreads;

public class ChildClass3 extends Thread {
	
	public void run() {
		System.out.println("Run method of third class");
	}

}




