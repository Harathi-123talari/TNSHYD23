package singleinheritence;
 class parent{
	void show()
	{
		System.out.println("coming to open the door");
		
	}
}
class child extends parent{
	void display()
	{
		System.out.println("opening the door");
	}
	
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child obj1=new child();
		obj1.show();
		obj1.display();
		

	}

}
