package herarchialinheritence;

class parent
{
	void feed() {
		System.out.println("feeding the child1");
	}
}
class child1 extends parent{
	void eat1() {
	System.out.println("my parent forcing me to eat");
	}
}
class child2 extends child1
{
	void eat2() {
		System.out.println("our parent forcing me to eat");
	}
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child2 obj1=new child2();
		obj1.feed();
		obj1.eat1();
		obj1.eat2();

	}

}
