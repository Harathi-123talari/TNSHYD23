package encapsulation2;

public class employee {
	
	private String name;
	private int id;
	private int salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public void section() {
		if(salary>=50000) {
			System.out.println("section A");
			
		}
		else if(salary>=30000) {
			System.out.println("section B");
			
		}
		else {
			System.out.println("section C");
		}
	}
	

}
