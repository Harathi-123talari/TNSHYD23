package encapsulation2;

public class employeemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employee emp=new employee();
		emp.setId(1);
		emp.setSalary(15000);
		
		emp.section();

	}

}
