package polymorphismoverriding;



class parent
{
	void feed() {
		System.out.println("feeding her child1");
	}
}
class child extends parent
{
	void feed() {
		System.out.println("feeding her child2");
		
	}
}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parent p1=new parent();
		p1.feed();
		parent p2=new child();
		p2.feed();

	}

}
