package constructorparam;

public class Student {
	String name;
	public Student(String n){
		name=n;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stu=new Student("harathi");
		System.out.println(stu.name);

	}

}
