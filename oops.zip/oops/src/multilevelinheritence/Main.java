package multilevelinheritence;
class parent1
{
	void feed() {
		System.out.println("feeding to parent2");
	}
}
class parent2 extends parent1
{
	void looking() {
		System.out.println("looking at child");
	}
}
class child extends parent2
{
	void running() {
		System.out.println("running away from parents");
	}
}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child c1=new child();
		c1.feed();
		c1.looking();
		c1.running();

	}

}
