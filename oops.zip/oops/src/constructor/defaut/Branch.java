package constructor.defaut;

public class Branch {


	String branch;
	public Branch(){
		branch="aiml";
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Branch br=new Branch();
		System.out.println(br.branch);
	}
}