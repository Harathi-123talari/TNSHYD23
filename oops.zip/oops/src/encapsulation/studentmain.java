package encapsulation;

public class studentmain {
	public static void main(String[] args) {
		student stu=new student();
		stu.setName("mahesh");
		stu.setAge(19);
		System.out.println(stu.eligible());
		
	}

}
