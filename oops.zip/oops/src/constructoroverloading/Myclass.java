package constructoroverloading;

public class Myclass {
	int num1;
	double num2;
	public Myclass() {
		System.out.println("default constructor called");
	}
	public Myclass(int x)
	{
		System.out.println("parameterized constructor called");
		num1=x;
		
	}
	public Myclass(int x,double y) {
		System.out.println("parameterized constructor called");
		num1=x;
		num2=y;
	}
	public void displaydata() {
		System.out.println("num1"+num1+"\nnum2"+num2);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myclass obj1=new Myclass();
		obj1.displaydata();
		Myclass obj2=new Myclass(5);
		obj2.displaydata();
		Myclass obj3=new Myclass(5,6.5);
		obj3.displaydata();

	}
	

}
