package scanner.com;

public class scex2 {

}
