package tns.day2;

public class A {

	int num1=10;
	static  int num2=20;
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int num3=30;
		System.out.println(num3);
		A add =new A();
		System.out.println(add.num1);
		System.out.println(num2);
		
		

	}

}
