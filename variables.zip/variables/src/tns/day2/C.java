package tns.day2;

class B{
	int b=20;
	static int c=30;
	
}

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int d=40;
		B b1= new B();
		System.out.println(b1.b);
		System.out.println(d);
		
		System.out.println(B.c);
		

	}

}
