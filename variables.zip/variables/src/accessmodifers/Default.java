package accessmodifers;



class B{
	int b=20;
	static int c=30;
	int show()
	{
		
		return 10;
	}
	
	static void display1() {
		System.out.println(10);
	}
}

 class Default {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1= new B();
		System.out.println(b1.b);
		System.out.println(b1.show());
		System.out.println(B.c);
	

	}

}
