package approach1m;

public class Student {
	int m1=20;
	static int m2=30;
	int display() {
		return 40;
		
	}
	static void display1()
	{
		System.out.println(50);
		
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		
		Student stu =new Student();
		System.out.println(stu.m1);
		System.out.println(stu.display());
		System.out.println(Student.m2);
		

	}

}
