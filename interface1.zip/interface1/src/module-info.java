/**
 * 
 */
/**
 * 
 */
module interface1 {
}