package interface1.com;

public class abstractmethodmain {
	public static void main(String[] args) {
	     MyClass obj = new MyClass();
	     obj.displayMessage(); 

}
}
