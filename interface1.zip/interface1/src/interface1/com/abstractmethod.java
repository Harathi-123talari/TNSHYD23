package interface1.com;

interface abstractmethod {
 void displayMessage();
}

class MyClass implements abstractmethod {
 public void displayMessage() {
     System.out.println("Hello from MyClass implementing MyInterface!");
 }
 
 
 }



